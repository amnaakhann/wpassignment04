import style from "./Spinner.module.css";
const Spinner = () => {
  return <div className={style.loader}></div>;
};

export default Spinner;
