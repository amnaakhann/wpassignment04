import "./Loading.css";
const Loading = () => {
  return (
    <div className="loader">
      <div className="justify-content-center jimu-primary-loading"></div>
    </div>
  );
};

export default Loading;
