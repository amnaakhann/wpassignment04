import SignUpForm from "../components/AuthForm/SignUpForm";

const SignupPage = () => {
  return (
    <>
      <SignUpForm />
    </>
  );
};
export default SignupPage;
