import LoginForm from "../components/AuthForm/LoginForm";

const Login = () => {
  return (
    <>
      <LoginForm />
    </>
  );
};
export default Login;
