import CartSection from "../Sections/CartSection";

const CartPage = () => {
  return <CartSection />;
};

export default CartPage;
