import AddProductsForm from "../components/AddProductsForm/AddProductsForm";
const AdminAddProduct = () => {
  return <AddProductsForm />;
};

export default AdminAddProduct;
