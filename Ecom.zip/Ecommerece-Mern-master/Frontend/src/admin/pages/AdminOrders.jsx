import Orders from "../components/Orders/Orders";
const AdminOrders = () => {
  return <Orders />;
};

export default AdminOrders;
