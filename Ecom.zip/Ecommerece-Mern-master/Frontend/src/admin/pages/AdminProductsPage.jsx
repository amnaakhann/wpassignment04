import Products from "../components/Products/Products";

const AdminProductsPage = () => {
  return <Products />;
};

export default AdminProductsPage;
