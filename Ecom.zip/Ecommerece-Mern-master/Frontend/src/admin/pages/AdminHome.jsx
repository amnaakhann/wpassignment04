import Hero from "../components/Hero/Hero";

const AdminHome = () => {
  return <Hero />;
};

export default AdminHome;
